RICK'S YELLOW BAIT HOUSE — NEW VISUAL DESIGN

1. Extract this ZIP.
2. Copy app and public into your project folder. Merge folders and replace matching files; do not delete your existing folders.
3. This project uses app/page.tsx. If you use src/app, copy page.tsx there instead.
4. Keep npm run dev running and refresh localhost:3000.

Includes: English/Spanish, created sunrise fishing image, real store photos, official brand artwork, bait filters, manual photo gallery, mobile navigation, reduced-motion support.

Brand artwork source pages:
PENN: https://www.pennfishing.com/
Daiwa: https://daiwa.us/
Shimano: https://fishshop.shimano.com/
Okuma: https://okumafishingusa.com/
Quantum: https://www.quantumfishing.com/

The fishing sunrise image is generated atmosphere, not documentary store photography.
Store hours match your supplied Google screenshot; weekend opening/closing boundary remains to be confirmed.
